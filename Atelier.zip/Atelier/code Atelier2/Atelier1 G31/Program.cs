﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atelier1_G31
{
    class Program
    {
        static void Main(string[] args)
        {
     
            Client cl2 = new Client("Mohammed", "Intissar", "ADD2");
            MAD somme1 = new MAD(50000);
            CompteEpargne cmpt1 = new CompteEpargne(cl2, somme1);

            cmpt1.crediter(somme1);
            cmpt1.debiter(new MAD(1500));
            cl2.afficherClient();
            //cmpt1.consulter();

            Console.ReadKey();

        }
    }
}
