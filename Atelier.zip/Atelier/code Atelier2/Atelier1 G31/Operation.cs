﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atelier1_G31
{
    class Operation
    {
        private int num;
        private static int cpt = 0;
        private DateTime dateop;
        private MAD montant;
        private string libelle; 

        public Operation(MAD montant , string lib)
        {
            this.num = ++cpt;
            this.dateop = DateTime.Now;
            this.montant = montant;
            this.libelle = lib;
        }

        public void afficheroperation()
        {
            Console.Write(this.num + "|" + this.dateop + "|" + this.libelle);
            this.montant.afficherSolde();
        }



    }
}
