﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atelier1_G31
{
    class Program
    {
        static void Main(string[] args)
        {
           string a = Console.ReadLine();
            string n = Console.ReadLine();
            string p = Console.ReadLine();
            Client cl1 = new Client(n, p, a);
            Client cl2 = new Client("Mohammed", "Intissar", "ADD2");
            MAD somme1 = new MAD(50000);
            Compte Cpt1 = new Compte(cl1,somme1);
            Compte Cpt2 = new Compte(cl2, somme1);
           
            Cpt1.consulter();
            Cpt2.consulter();

            Cpt1.crediter(new MAD(1000));
            Cpt1.debiter(new MAD(5000));
            Cpt2.verser(Cpt1, new MAD(1000));

            Cpt1.consulter();
            Cpt2.consulter();
            Console.ReadKey();

        }
    }
}
