﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeviseLLibraries
{
 public   interface IDevise
    {
        void afficherDevise();
        Devise ConvertTo(string type);
         Devise add(Devise m1, Devise m2);
    }
}
