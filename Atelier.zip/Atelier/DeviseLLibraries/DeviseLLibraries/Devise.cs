﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeviseLLibraries
{
    public abstract class Devise :IDevise
    {

        private double valeur;
        private string type;

        public Devise(double val, string t)
        {
            this.valeur = val;
            this.type = t;
        }
        public void afficherDevise()
        {
            Console.WriteLine(this.valeur+" "+this.type);
        }


        public static bool operator >(Devise m1, Devise m2) => (m1.valeur > m2.valeur);
        public static bool operator <(Devise m1, Devise m2) => (m1.valeur < m2.valeur);

        public  Devise add(Devise m1, Devise m2)
        {
            if (m1.GetType() == m2.GetType()) {
                this.valeur = m1.valeur + m2.valeur;
            }
            return this;
        }
        public static Devise operator +(Devise m1, Devise m2)
        {
            Devise res;
            if (m1.GetType() == m2.GetType())
            {
                if (m1 is MAD)
                {
                    res = new MAD(m1.valeur + m2.valeur);
                    return res; 
                }
                else if(m1 is EU)
                {
                    res = new EU(m1.valeur + m2.valeur);
                    return res;

                }
                else
                {
                    res = new US(m1.valeur + m2.valeur);
                    return res;

                }

            }
            else
            {
                Console.WriteLine("types diffe");
                return null;
                
            }
        }


        public abstract Devise ConvertTo(string type);
      public double  echange( double taux)
        {
            return this.valeur * taux;
        }
    }
}
