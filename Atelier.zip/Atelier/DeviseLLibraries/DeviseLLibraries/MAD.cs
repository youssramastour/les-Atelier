﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeviseLLibraries
{
  public   class MAD:Devise
    {
        private static double tauxEnEuro=0.094;
        private static double tauxEnDollar =0.11;
       public MAD(double val) : base(val, "MAD")
        {
        }

        public override Devise ConvertTo(string type)
        {
            Devise res;
            if (type == "EU")
            {
                res = new EU(this.echange(tauxEnEuro));
                return res;
            }
            else if(type=="US")
            {
                res = new US(this.echange(tauxEnDollar));
                return res;
            }
            else
            {
                Console.WriteLine("invalid type");
                return this;
            }
        }
    }
}
