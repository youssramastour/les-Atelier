﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeviseLLibraries
{
  public  class EU : Devise
    {

        private static double tauxEnMAD = 10.67;
        private static double tauxEnDollar = 1.19;

        public EU(double val):base(val, "EU")
        {

        }


        public override Devise ConvertTo(string type)
        {
            Devise res;
            if (type == "MAD")
            {
                res = new MAD(this.echange(tauxEnMAD));
                return res;
            }
            else if (type == "US")
            {
                res = new US(this.echange(tauxEnDollar));
                return res;
            }
            else
            {
                Console.WriteLine("invalid type");
                return this;
            }
        }
    }
}
