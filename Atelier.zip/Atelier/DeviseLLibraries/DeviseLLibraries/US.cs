﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeviseLLibraries
{
   public class US:Devise
    {
        private static double tauxEnMAD = 8.96;
        private static double tauxEnEuro = 0.84;
        public US(double val) : base(val, "US")
        {

        }

        public override Devise ConvertTo(string type)
        {
            Devise res;
            if (type == "MAD")
            {
                res = new MAD(this.echange(tauxEnMAD));
                return res;
            }
            else if (type == "EU")
            {
                res = new EU(this.echange(tauxEnEuro));
                return res;
            }
            else
            {
                Console.WriteLine("invalid type");
                return this;
            }
        }
    }
}
